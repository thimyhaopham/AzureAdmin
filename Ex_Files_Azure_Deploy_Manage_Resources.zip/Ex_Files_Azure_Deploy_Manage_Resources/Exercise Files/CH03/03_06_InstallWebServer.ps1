﻿get-windowsfeature web-server | install-windowsfeature
mkdir 'c:\Distros'