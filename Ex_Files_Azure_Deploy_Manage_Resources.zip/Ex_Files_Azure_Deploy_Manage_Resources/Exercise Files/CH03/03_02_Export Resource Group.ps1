﻿#Export Resource Group

Export-AzResourceGroup -ResourceGroupName "CandCVMPortal"

