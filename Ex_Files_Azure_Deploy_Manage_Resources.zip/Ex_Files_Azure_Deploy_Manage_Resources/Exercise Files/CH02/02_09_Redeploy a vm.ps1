﻿#Redeploy a vm

Set-AzVM -Redeploy -ResourceGroupName "CreateAndConfigureVmPS" -Name "az104ps"