﻿namespace IAmSap.Chapter3.App.Models.Config
{
    public class ProductConfig
    {
        public string ServiceUrl { get; set; }
        public int RowCount { get; set; }
    }
}